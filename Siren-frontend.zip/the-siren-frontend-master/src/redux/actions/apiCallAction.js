export const apiCallAction = (data) => ({
    type: "API_CALL",
    payload: data
})
