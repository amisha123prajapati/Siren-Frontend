export const hollywoodApiCallAction = (data) => ({
    type: "HOLLYWOOD_API_CALL",
    payload: data
})
