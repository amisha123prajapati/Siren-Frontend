export const foodApiCallAction = (data) => ({
    type: "FOOD_API_CALL",
    payload: data
})
