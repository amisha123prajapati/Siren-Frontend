export const techApiCallAction = (data) => ({
    type: "TECH_API_CALL",
    payload: data
})
