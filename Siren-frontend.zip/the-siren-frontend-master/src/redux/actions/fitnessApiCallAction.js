export const fitnessApiCallAction = (data) => ({
    type: "FITNESS_API_CALL",
    payload: data
})
