export const blogContentAction = (content) => ({
    type: "GET_CONTENT",
    payload: content
})
