export const suggestionAction = (data) => ({
    type: "SUGGESST",
    payload: data
})
