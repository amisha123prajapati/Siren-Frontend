exports.NavItems = [
    {name: "Home", url: "/"},
    {name: "Bollywood", url: "/bollywood"},
    {name: "Technology", url: "/technology"},
    {name: "Hollywood", url: "/hollywood"},
    {name: "Fitness", url: "/fitness"},
    {name: "Food", url: "/food"}
]
