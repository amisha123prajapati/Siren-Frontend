# The Siren

A diverse blog webapp for posting various articles like Technology, Fitness, Food, Bollywood, Hollywood etc.

## View Project Live: 

https://the-siren.netlify.app/

## Features

- Post amazing articles
- Light/dark mode toggle
- Like, comment, share
- Interactive platform
